library(shiny)
library(ggvis)
library(dplyr)

dat <- read.csv('../data/cleandata/cleanscores.csv', stringsAsFactors = FALSE)


# Define UI for application that draws a histogram
ui <- fluidPage(
  
  # Application title
  titlePanel("Grades Distribution"),
    # Show a plot of the generated distribution
    mainPanel(
      fluidRow(
      tableOutput(outputId = "df"),
      ggvisOutput("barchart")
      )
    )
  )


# Define server logic required to draw a histogram
server <- function(input, output) {
  
  dat_1 = as.data.frame( dat %>% group_by(Letter) %>% summarise(Freq = n() ))
  dat_1$Prop = dat_1$Freq / nrow(dat)
  
  
  output$df = renderTable(dat_1)
  # A reactive expression with the ggvis plot
  vis <- reactive({
    grade_labs <- c('A+', 'A', 'A-', 'B+', 'B', 'B-', 'C+', 'C', 'C-', 'D', 'F')
    dat$Letter <- factor(dat$Letter, levels = grade_labs, ordered = TRUE)
    #grade_freqs <- table(grade)
    dat %>% 
      ggvis(x = ~Letter, fill := "tomato") %>% 
      layer_bars(stroke := 'tomato', 
                 fillOpacity := 0.8, fillOpacity.hover := 1) %>%
      add_axis("y", title = "frequency")
  })
  
  vis %>% bind_shiny("barchart")
}

# Run the application 
shinyApp(ui = ui, server = server)

