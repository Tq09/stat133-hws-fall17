library(shiny)
library(ggvis)
library(dplyr)

source('../code/functions.R')

dat <- read.csv('../data/cleandata/cleanscores.csv', stringsAsFactors = FALSE)

# Variables that can be put on the x and y axes
axis_vars <- names(dat)[-ncol(dat)]
names(axis_vars) <- names(dat)[-ncol(dat)]

# grade labels (correct order)
grade_labs <- c('A+', 'A', 'A-', 'B+', 'B', 'B-', 'C+', 'C', 'C-', 'D', 'F')


# Define UI for application that draws a histogram
ui <- fluidPage(
  
  # Application title
  titlePanel("Grade Visualizer"),
  
  # Sidebar with different widgets depending on the selected tab
  sidebarLayout(
    sidebarPanel(
      conditionalPanel(condition = "input.tabselected==1",
                       h4("Grades Distribution"),
                       tableOutput("frequencies")),
      conditionalPanel(condition = "input.tabselected==2",
                       selectInput("var", "X-axis variable", axis_vars, 
                                   selected = "HW1"),
                       sliderInput("bins", "Bin Width", min = 1, max = 10, value = 10)),
      conditionalPanel(condition = "input.tabselected==3",
                       selectInput("xvar", "X-axis variable", axis_vars, 
                                   selected = "Test1"),
                       selectInput("yvar", "Y-axis variable", axis_vars, 
                                   selected = "Overall"),
                       sliderInput("opacity", "Opacity", min = 0, max = 1, value = 0.5),
                       radioButtons("loess", "Show line", 
                                    choices = list("none" = "none",
                                                   "lm" = "lm", 
                                                   "loess" = "loess"),
                                    selected = "none")
      )
    ),
    mainPanel(
      tabsetPanel(type = "tabs",
                  tabPanel("Barchart", value = 1, 
                           ggvisOutput("barchart")),
                  tabPanel("Histogram", value = 2, 
                           ggvisOutput("histogram"),
                           h5("Summary Statistics"),
                           verbatimTextOutput("summary")),
                  tabPanel("Scatterplot", value = 3, 
                           ggvisOutput("scatterplot"),
                           h5("Correlation:"),
                           verbatimTextOutput("correlation")),
                  id = "tabselected"
      )
    )
  )
)


# Define server logic required to draw a histogram
server <- function(input, output) {
  # Barchart for letter grade
  vis_barchart <- reactive({
    dat$Grade <- factor(dat$Grade, levels = grade_labs, ordered = TRUE)
    
    dat %>% 
      ggvis(x = ~Grade, fill := "#5e95ed") %>% 
      layer_bars(stroke := '#5e95ed', 
                 fillOpacity := 0.8, fillOpacity.hover := 1) %>%
      add_axis("y", title = "frequency")
  })
  
  vis_barchart %>% bind_shiny("barchart")
  
  output$frequencies <- renderTable({
    dat$Grade <- factor(dat$Grade, levels = grade_labs, ordered = TRUE)
    dat %>% 
      group_by(Grade) %>% 
      summarise(Freq = n()) %>% 
      mutate(Prop = Freq/sum(Freq))
  })
  
  # Histograms
  vis_histogram <- reactive({
    # Normally we could do something like ggvis(x = ~HW1),
    # but since the inputs are strings, we need to do a little more work.
    var <- prop("x", as.symbol(input$var))
    
    dat %>% 
      ggvis(x = var, fill := "#abafb5") %>% 
      layer_histograms(stroke := 'white',
                       width = input$bins)
  })
  
  vis_histogram %>% bind_shiny("histogram")
  
  # Generate a summary of the dataset ----
  output$summary <- renderPrint({
    stats <- summary_stats(dat[,input$var])
    print_stats(stats)
  })
  
  # Scatterplots
  output$correlation <- renderText({
    cor(dat[ ,input$xvar], dat[ ,input$yvar])
  })
  
  # A reactive expression with the ggvis plot
  vis_scatter <- reactive({
    # Labels for axes
    xvar_name <- names(axis_vars)[axis_vars == input$xvar]
    yvar_name <- names(axis_vars)[axis_vars == input$yvar]
    
    # Normally we could do something like props(x = ~HW1, y = ~HW2),
    # but since the inputs are strings, we need to do a little more work.
    xvar <- prop("x", as.symbol(input$xvar))
    yvar <- prop("y", as.symbol(input$yvar))
    
    scatter <- dat %>%
      ggvis(x = xvar, y = yvar) %>%
      layer_points(size := 50, size.hover := 200,
                   fillOpacity := input$opacity, 
                   fillOpacity.hover := 0.5)
    #add_tooltip(movie_tooltip, "hover") %>%
    
    # type of line to be added
    switch(input$loess, 
           'none'  = scatter,
           'lm' = scatter %>% layer_model_predictions(model = 'lm', stroke := 'blue'),
           'loess' = scatter %>% layer_model_predictions(model = 'loess', stroke := 'tomato'))
  })
  
  vis_scatter %>% bind_shiny("scatterplot")
}

# Run the application 
shinyApp(ui = ui, server = server)


